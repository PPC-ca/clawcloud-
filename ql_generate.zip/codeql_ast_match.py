class ASTMatcher:
    def __init__(self, tree1_root, tree2_root):
        self.tree1_root = tree1_root
        self.tree2_root = tree2_root
        self.matched = []

    def count_descendants(self, node):
        return sum(self.count_descendants(child) for child in node.children) + 1

    def get_nth_descendant(self, node, n):
        stack = [node]
        visited = []
        while stack:
            curr = stack.pop()
            visited.append(curr)
            stack.extend(reversed(curr.children))
            if len(visited) > n:
                return visited[n]
        return None

    def get_all_descendants(self, node):
        descendants = [node]
        stack = [node]
        while stack:
            curr = stack.pop()
            for child in reversed(curr.children):
                descendants.append(child)
                stack.append(child)
        return descendants

    def node_eq(self, n1, n2):
        return (
            n1.type == n2.type and
            n1.value == n2.value and
            len(n1.children) == len(n2.children)
        )

    def node_approx_eq(self, n1, n2):
        return (
            n1.type == n2.type and
            len(n1.children) == len(n2.children)
        )

    def match_unit(self, n1, n2):
        if self.node_eq(n1, n2):
            p1 = n1.parent
            p2 = n2.parent
            if p1 and p2 and self.node_eq(p1, p2):
                for i in range(self.count_descendants(n1)):
                    if not self.node_eq(self.get_nth_descendant(n1, i), self.get_nth_descendant(n2, i)):
                        break
                else:
                    return 1

            for i in range(self.count_descendants(n1)):
                if not self.node_eq(self.get_nth_descendant(n1, i), self.get_nth_descendant(n2, i)):
                    break
            else:
                return 2

        if self.node_approx_eq(n1, n2):
            for i in range(self.count_descendants(n1)):
                if not self.node_approx_eq(self.get_nth_descendant(n1, i), self.get_nth_descendant(n2, i)):
                    break
            else:
                return 3

        if self.node_eq(n1, n2):
            p1 = n1.parent
            p2 = n2.parent
            if p1 and p2 and self.node_approx_eq(p1, p2):
                return 4
            return 5

        if self.node_approx_eq(n1, n2):
            return 6

        return None

    def match(self):
        matched = []
        visited1 = set()
        visited2 = set()
        # ark = False

        # Phase 1-3: strict or deep match
        for level in [1, 2, 3]:
            for node1 in self.get_all_descendants(self.tree1_root):
                if node1 in visited1:
                    continue
                for node2 in self.get_all_descendants(self.tree2_root):
                    if node2 in visited2:
                        continue
                    # if node1.location == '198:2:198:10' and node2.location == '207:2:207:10':
                    #     print(f"1111111111111 Matching {node1} with {node2} at level {level}")
                    #     ark = True
                    if self.match_unit(node1, node2) == level:
                        # d = min(self.count_descendants(node1), self.count_descendants(node2))
                        for n in range(self.count_descendants(node1)):
                            d1 = self.get_nth_descendant(node1, n)
                            d2 = self.get_nth_descendant(node2, n)
                            # if ark:
                            #     print(f"2222222222222 Matching {d1} with {d2} at level {level}")
                            #     print(d1 and d2 and (d1 not in visited1) and (d2 not in visited2))
                            #     print(self.count_descendants(node1), n)
                            #     ark = False
                            if d1 and d2 and (d1 not in visited1) and (d2 not in visited2):
                                matched.append((d1, d2))
                                visited1.add(d1)
                                visited2.add(d2)

        # Phase 4-6: relaxed match
        for level in [4, 5, 6]:
            for node1 in self.get_all_descendants(self.tree1_root):
                if node1 in visited1:
                    continue
                for node2 in self.get_all_descendants(self.tree2_root):
                    if node2 in visited2:
                        continue
                    # if node1.location == '176:12:176:21' and node2.location == '178:12:178:21':
                    #     print(f"Matching {node1} with {node2} at level {level}")
                    #     ark = True
                    if self.match_unit(node1, node2) == level:
                        # if ark:
                        #     print(f"22222222222 Matching {node1} with {node2} at level {level}")
                        #     print(node1 not in visited1 and node2 not in visited2)
                        #     ark = False
                        if node1 not in visited1 and node2 not in visited2:
                            matched.append((node1, node2))
                            visited1.add(node1)
                            visited2.add(node2)

        self.matched = matched
        return matched
