from editscript import *
from codeql_ast_read import ASTNode

def process_node(current_path, node, is_first=True, root_target=None):
    cond = ""
    para_list = set()
    # print("processing node: ",node)
    # print("node.type:",node.type == "ReturnStmt")
    # 检查当前节点是否有target_id属性且不是root_target
    if hasattr(node, 'target_id') and node.target_id != root_target:
        if is_first:
            cond = f"{current_path}={node.target_id}"
            para_list.add(f"{node.type} {node.target_id}")
            is_first = False
        else:
            cond = f"\nand {current_path}={node.target_id}"
            para_list.add(f"{node.type} {node.target_id}")
        return cond, list(para_list)
    # 处理各种节点类型
    if node.type == "IfStmt":
        if node.children:
            cond_part, paras = process_node(f"{current_path}.getCondition().({node.children[0].type})", node.children[0], is_first, root_target)
            cond += cond_part
            para_list.update(paras)
            is_first = (cond == "")
            
            for i, child in enumerate(node.children[1:]):
                if child.type == "BlockStmt":
                    cond_part, paras = process_node(f"{current_path}.getThen().({child.type})", child, is_first, root_target)
                    if cond_part:
                        cond += cond_part
                        para_list.update(paras)
                        is_first = False
                else:
                    cond_part, paras = process_node(f"{current_path}.getThen().({child.type})", child, is_first, root_target)
                    if cond_part:
                        cond += cond_part
                        para_list.update(paras)
                        is_first = False
                    
    elif node.type == "FunctionCall":
        func_name = node.value.replace("call to ", "")
        cond_part = f"{current_path}.getTarget().hasName(\"{func_name}\")"
        if not is_first:
            cond_part = f"\nand {cond_part}"
        cond += cond_part
        is_first = False
        
        for i, child in enumerate(node.children):
            cond_part, paras = process_node(f"{current_path}.getArgument({i}).({child.type})", child, is_first, root_target)
            if cond_part:
                cond += cond_part
                para_list.update(paras)
                is_first = False
                
    elif node.type == "NotExpr":
        if node.children:
            cond_part, paras = process_node(f"{current_path}.getOperand().({node.children[0].type})", node.children[0], is_first, root_target)
            if cond_part:
                cond += cond_part
                para_list.update(paras)
                is_first = False
                
    elif node.type == "VariableAccess":
        #print("VariableAccess node: ", node,hasattr(node, 'out_var'))
        if hasattr(node, 'out_var'):
            cond_part = f"{current_path}.getTarget()={node.out_var}"
            para_list.add(f"Variable {node.out_var}")
        else:
            var_type = node.features["Type"].split("]")[-1].strip()
            cond_part = f"{current_path}.getType().hasName(\"{var_type}\")"
            
        if not is_first:
            cond_part = f"\nand {cond_part}"
        cond += cond_part
        is_first = False
        
    elif node.type == "Literal":
        cond_part = f"{current_path}.getValue()=\"{node.value}\""
        if not is_first:
            cond_part = f"\nand {cond_part}"
        cond += cond_part
        is_first = False
        
    elif node.type == "ExprStmt":
        if node.children:
            child = node.children[0]
            cond_part, paras = process_node(f"{current_path}.getExpr().({child.type})", child, is_first, root_target)
            if cond_part:
                cond += cond_part
                para_list.update(paras)
                is_first = False

    elif node.type == "ReturnStmt":
        if node.children:
            child = node.children[0]
            cond_part, paras = process_node(f"{current_path}.getExpr().({child.type})", child, is_first, root_target)
            if cond_part:
                cond += cond_part
                para_list.update(paras)
                is_first = False
    elif node.type == "BlockStmt":
        if  node.children:
            for i,child in enumerate(node.children):
                cond_part, paras = process_node(f"{current_path}.getStmt({i}).({child.type})", child, is_first, root_target)
                if cond_part:
                    cond += cond_part
                    para_list.update(paras)
                    is_first = False     
    elif node.type == "UnaryMinusExpr":
        if node.children:
            child = node.children[0]
            cond_part, paras = process_node(f"{current_path}.getChild(0).({child.type})", child, is_first, root_target)
            if cond_part:
                cond += cond_part
                para_list.update(paras)
                is_first = False
    elif node.type == "AssignExpr":
        if node.children and len(node.children) >= 2:
            # 处理左值
            lvalue = node.children[0]
            cond_part, paras = process_node(f"{current_path}.getLValue().({lvalue.type})", lvalue, is_first, root_target)
            if cond_part:
                cond += cond_part
                para_list.update(paras)
                is_first = False
            
            # 处理右值
            rvalue = node.children[1]
            cond_part, paras = process_node(f"{current_path}.getRValue().({rvalue.type})", rvalue, is_first, root_target)
            if cond_part:
                cond += cond_part
                para_list.update(paras)
                is_first = False
    elif node.type == "DeclStmt":
        pass
        # if node.children:
        #     # 处理声明语句中的每个变量声明条目
        #     for i, child in enumerate(node.children):
        #         cond_part, paras = process_node(f"{current_path}.getChild({i})", child, is_first, root_target)
        #         if cond_part:
        #             cond += cond_part
        #             para_list.update(paras)
        #             is_first = False

    elif node.type == "VariableDeclarationEntry":
        pass
        # # 处理变量声明条目
        # var_name = node.value.replace("definition of ", "")
        # cond_part = f"{current_path}.getName() = \"{var_name}\""
        # if not is_first:
        #     cond_part = f"\nand {cond_part}"
        # cond += cond_part
        # is_first = False
        
        # # 如果有类型信息，可以添加类型检查
        # if hasattr(node, 'var_type'):
        #     cond_part = f"{current_path}.getType().toString() = \"{node.var_type}\""
        #     if not is_first:
        #         cond_part = f"\nand {cond_part}"
        #     cond += cond_part
        #     is_first = False
        
    else:
        print("unknown node type: ", node.type)
        return current_path, list()
    
    if hasattr(node, 'cfg_refine'):
        for refine_cond, refine_param in node.cfg_refine:
            if not is_first:
                cond += "\nand "
            cond += refine_cond
            para_list.add(refine_param)
            is_first = False
    return cond, list(para_list)

class ASTDelPredicateGenerator:
    def generate(self, root_node, predicate_nr):
        root_target = f"target_{predicate_nr}"
        conditions, params = process_node(root_target, root_node, root_target=root_target)
        params.append(f"{root_node.type} {root_target}")
        
        param_str = ", ".join(sorted(params))
        return f"""predicate func_{predicate_nr}({param_str}) {{
\t{conditions} 
}}""" , param_str

class ASTAddPredicateGenerator:
    def generate(self, root_node, predicate_nr):
        exists_target = root_node.target_id
        conditions, params = process_node(exists_target, root_node, root_target=exists_target)        
        param_str = ", ".join(sorted(params))
        return f"""predicate func_{predicate_nr}({param_str}) {{
\texists({root_node.type} {root_node.target_id} |
\t\t{conditions}
\t)
}}""", param_str

class ASTMovePredicateGenerator:
    def generate(self, root_node, predicate_nr):
        root_target = f"target_{predicate_nr}"
        conditions, params = process_node(root_target, root_node, root_target=root_target)
        params.append(f"{root_node.type} {root_target}")
        
        param_str = ", ".join(sorted(params))
        return f"""predicate func_{predicate_nr}({param_str}) {{
\t{conditions}
}}""", param_str

class ASTUpdatePredicateGenerator:
    def generate(self, old_node, new_node, predicate_nr):
        target = f"target_{predicate_nr}"
        old_cond, old_params = process_node(target, old_node, root_target=target)
        new_cond, new_params = process_node(target, new_node, root_target=target)
        
        # 合并参数并添加目标参数
        params = set(old_params + new_params)
        params.add(f"{old_node.type} {target}")
        
        # 取反新条件
        negated_new_cond = "\n\tand not ".join(new_cond.split("\nand "))
        
        param_str = ", ".join(sorted(params))
        return f"""predicate func_{predicate_nr}({param_str}) {{
\t{old_cond}
\tand not {negated_new_cond}
}}""", param_str

def find_matched_node(node, match_pairs):
    for old_node, new_node in match_pairs:
        if id(node) == id(old_node):
            if hasattr(new_node, 'out_var'):
                node.out_var = new_node.out_var
            #print(new_node)
            return new_node
        if id(node) == id(new_node):
            if hasattr(old_node, 'out_var'):
                new_node.out_var = old_node.out_var
            #print(old_node)
            return old_node
    return None
def is_duplicate(node, match_pairs, seen_nodes):
    print(node)
    if id(node) in seen_nodes:
        print("true")
        return True
    
    for old_node, new_node in match_pairs:
        if (id(node) == id(new_node) and  id(old_node) in seen_nodes) or (id(node) == id(old_node) and  id(new_node) in seen_nodes):
            print("true")
            return True
    print("false")
    return False
def cfg_refine(nodes, match_pairs=None):
    refined_nodes = []
    seen_nodes = set()  # 用于去重
    target_counter = len(nodes)  # 从当前节点数量开始计数
    
    # 如果没有提供match_pairs，则初始化为空列表
    if match_pairs is None:
        match_pairs = []
    
    # 首先为输入节点分配target_id（如果还没有）
    for i, node in enumerate(nodes):
        if not hasattr(node, 'target_id'):
            node.target_id = f"target_{i}"
        seen_nodes.add(id(node))  # 记录已处理节点
    
    # 处理每个节点
    for node in nodes:
        # 为当前节点收集优化条件
        cfg_conditions = []
        # 规则1: 控制流语句(If/Switch/For/While)
        if node.parent and node.parent.type in ["IfStmt", "SwitchStmt", "ForStmt", "WhileStmt"]:
            # 情况1:节点在条件部分
            if node in node.parent.children and node.parent.children.index(node) == 0:
                # 引用then/do体中的语句
                body_nodes = node.parent.children[1:]
                for i,body_node in enumerate(body_nodes):
                    if (hasattr(body_node, 'edittype') == hasattr(node, 'edittype')):
                        if id(body_node) not in seen_nodes :
                            body_node.target_id = f"target_{target_counter}"
                            refined_nodes.append(body_node)
                            seen_nodes.add(id(body_node))
                            matched_node = find_matched_node(body_node, match_pairs)
                            if matched_node:
                                matched_node.target_id = f"target_{target_counter}"
                                seen_nodes.add(id(matched_node))
                            target_counter += 1
                        if body_node.type == "BlockStmt":
                            for stmt in body_node.children:
                                if id(stmt) not in seen_nodes :
                                    stmt.target_id = f"target_{target_counter}"
                                    refined_nodes.append(stmt)
                                    seen_nodes.add(id(stmt))
                                    matched_node = find_matched_node(stmt, match_pairs)
                                    if matched_node:
                                        matched_node.target_id = f"target_{target_counter}"
                                        seen_nodes.add(id(matched_node))
                                    target_counter += 1
                                cfg_conditions.append((f"{node.target_id}.getParent().({node.parent.type}).getChild({i}).({body_node.type}).getStmt({body_node.children.index(stmt)})={stmt.target_id}",f"{stmt.type} {stmt.target_id}"))
                        else:
                            cfg_conditions.append((f"{node.target_id}.getParent().({node.parent.type}).getThen()={body_node.target_id}",f"{body_node.type} {body_node.target_id}"))
            
            # 情况2: 节点在then/do体中
            elif node in node.parent.children and node.parent.children.index(node) > 0:
                # 引用条件表达式
                cond_node = node.parent.children[0]
                if (hasattr(cond_node, 'edittype') == hasattr(node, 'edittype')):
                    if id(cond_node) not in seen_nodes :
                            cond_node.target_id = f"target_{target_counter}"
                            refined_nodes.append(cond_node)
                            seen_nodes.add(id(cond_node))
                            matched_node = find_matched_node(cond_node, match_pairs)
                            if matched_node:
                                matched_node.target_id = f"target_{target_counter}"
                                seen_nodes.add(id(matched_node))
                            target_counter += 1
                    cfg_conditions.append((f"{node.target_id}.getParent().({node.parent.type}).getCondition()={cond_node.target_id}",f"{cond_node.type} {cond_node.target_id}"))
        
        # 规则2: 赋值或比较操作
        if node.parent and node.parent.type in ["AssignExpr", "BinaryExpr"]:
            siblings = [child for child in node.parent.children if child != node]
            for sibling in siblings:
                if (hasattr(sibling, 'edittype') == hasattr(node, 'edittype')):
                    if id(sibling) not in seen_nodes :
                            sibling.target_id = f"target_{target_counter}"
                            refined_nodes.append(sibling)
                            seen_nodes.add(id(sibling))
                            matched_node = find_matched_node(sibling, match_pairs)
                            if matched_node:
                                matched_node.target_id = f"target_{target_counter}"
                                seen_nodes.add(id(matched_node))
                            target_counter += 1
                    cfg_conditions.append((f"{node.target_id}.getParent().({node.parent.type}).getOperand({node.parent.children.index(sibling)})={sibling.target_id}",f"{sibling.type} {sibling.target_id}"))
        
        # 规则3: 数组相关表达式
        if node.parent and node.parent.type in ["ArrayAccess", "ArrayCreation"]:
            siblings = [child for child in node.parent.children if child != node]
            for sibling in siblings:
                if (hasattr(sibling, 'edittype') == hasattr(node, 'edittype')):
                    if id(sibling) not in seen_nodes :
                            sibling.target_id = f"target_{target_counter}"
                            refined_nodes.append(sibling)
                            seen_nodes.add(id(sibling))
                            matched_node = find_matched_node(sibling, match_pairs)
                            if matched_node:
                                matched_node.target_id = f"target_{target_counter}"
                                seen_nodes.add(id(matched_node))
                            target_counter += 1
                    cfg_conditions.append((f"{node.target_id}.getParent().({node.parent.type}).getOperand({node.parent.children.index(sibling)})={sibling.target_id}",f"{sibling.type} {sibling.target_id}"))
        
        # 规则4: 表达式节点，引用最外层包裹表达式
        if node.type.endswith("Expr") and node.parent and node.parent.type.endswith("Expr"):
            current = node.parent
            while current.parent and current.parent.type.endswith("Expr"):
                current = current.parent
            if (hasattr(current, 'edittype') == hasattr(node, 'edittype')):
                if current != node and id(current) not in seen_nodes :
                    current.target_id = f"target_{target_counter}"
                    refined_nodes.append(current)
                    seen_nodes.add(id(current))
                    matched_node = find_matched_node(current, match_pairs)
                    if matched_node:
                        matched_node.target_id = f"target_{target_counter}"
                        seen_nodes.add(id(matched_node))
                    target_counter += 1
                    cfg_conditions.append((f"{node.target_id}.getParent()*.getExpr()={current.target_id}",f"{current.type} {current.target_id}"))
        
        # 规则5: 语句节点，引用父语句和兄弟语句
        if node.type.endswith("Stmt") and node.parent:
            # 引用父语句
            if node.parent.type.endswith("Stmt") and id(node.parent) not in seen_nodes and (hasattr(node.parent, 'edittype') == hasattr(node, 'edittype')):
                node.parent.target_id = f"target_{target_counter}"
                refined_nodes.append(node.parent)
                seen_nodes.add(id(node.parent))
                matched_node = find_matched_node(node.parent, match_pairs)
                if matched_node:
                    matched_node.target_id = f"target_{target_counter}"
                    seen_nodes.add(id(matched_node))
                target_counter += 1
                cfg_conditions.append((f"{node.target_id}.getParent()={node.parent.target_id}",f"{node.parent.type} {node.parent.target_id}"))
            
            # 引用兄弟语句
            if hasattr(node.parent, 'children'):
                siblings = [child for child in node.parent.children if child != node and child.type.endswith("Stmt")]
                for sibling in siblings:
                    if id(sibling) not in seen_nodes and (hasattr(sibling, 'edittype') == hasattr(node, 'edittype')):
                        sibling.target_id = f"target_{target_counter}"
                        refined_nodes.append(sibling)
                        seen_nodes.add(id(sibling))
                        matched_node = find_matched_node(sibling, match_pairs)
                        if matched_node:
                            matched_node.target_id = f"target_{target_counter}"
                            seen_nodes.add(id(matched_node))
                        target_counter += 1
                    if node.parent.type == "BlockStmt":
                        cfg_conditions.append((f"{node.target_id}.getParent().({node.parent.type}).getStmt({node.parent.children.index(sibling)})={sibling.target_id}",f"{sibling.type} {sibling.target_id}"))
                    else:
                        cfg_conditions.append((f"{node.target_id}.getParent().({node.parent.type}).getChild({node.parent.children.index(sibling)})={sibling.target_id}",f"{sibling.type} {sibling.target_id}"))
        
        # 将优化条件添加到节点
        if cfg_conditions:
            if not hasattr(node, 'cfg_refine'):
                node.cfg_refine = []
            node.cfg_refine.extend(cfg_conditions)
    return refined_nodes

def generate_key_variable_conditions(key_variable_nodes):
    cond = ""
    for (node, bool_cond) in key_variable_nodes:
        if bool_cond:
            # 提取类型名称，去除中括号部分
            type_str = node.features["Type"]
            # 使用split和strip提取所需类型名称
            type_name = type_str.split("]")[-1].strip()
            
            # 添加类型检查条件
            cond += f"\nand {node.out_var}.getType().hasName(\"{type_name}\")"
            # 添加父作用域检查条件
            cond += f"\nand {node.out_var}.getParentScope+() = func"
    return cond