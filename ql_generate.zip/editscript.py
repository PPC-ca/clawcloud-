from codeql_ast_read import ASTBuilder
from codeql_ast_match import ASTMatcher

def find_matched_parent(node, M):
    """查找节点在匹配集合M中的最近父节点"""
    current = node.parent
    while current:
        for m in M:
            if m[1] == current:
                return current
        current = current.parent
    return None

def find_insert_position(new_node, new_parent):
    """确定新节点在其父节点children列表中的位置"""
    if not new_parent or not new_parent.children:
        return 0
    return new_parent.children.index(new_node)

def nodes_equal(node1, node2):
    """比较两个AST节点是否内容相同"""
    return (node1.type == node2.type and 
            node1.value == node2.value and 
            len(node1.children) == len(node2.children))

def get_node_changes(old_node, new_node):
    """提取两个匹配节点之间的具体变化"""
    changes = {}
    if old_node.type != new_node.type:
        changes['type'] = (old_node.type, new_node.type)
    if old_node.value != new_node.value:
        changes['value'] = (old_node.value, new_node.value)
    return changes

def is_node_in_deletions(node, deletions):
    """检查节点是否在删除列表中"""
    return any(d[1] == node for d in deletions)

def is_node_in_insertions(node, insertions):
    """检查节点是否在新增列表中"""
    return any(i[1] == node for i in insertions)

def has_parent_in_list(node, node_list, is_deletion=True):
    """检查节点的父节点是否在指定的列表中"""
    if not node.parent:
        return False
    if is_deletion:
        return any(d[1] == node.parent for d in node_list)
    else:
        return any(i[1] == node.parent for i in node_list)

def generate_editscript(old_ast, new_ast, M):
    editscript = []
    affected_nodes = set()  # 记录被影响的节点
    node_counter = 0
    node_target_map = {}  # 记录节点到target_id的映射
    priority_order = {'delete': 0, 'insert': 1, 'move': 2, 'update': 3}  # 操作优先级

    # 1. 收集所有可能的编辑操作（暂不分配target_id）
    all_edits = []
    
    # 收集删除操作
    deletions = []
    for old_node in old_ast.linked_nodes:
        if not any(old_node == m[0] for m in M) and not (old_node.type == 'TopLevelFunction'):
            deletions.append(('delete', old_node, old_node.parent if old_node.parent else None))
            affected_nodes.add(old_node)
    filtered_deletions = [d for d in deletions if not has_parent_in_list(d[1], deletions)]
    all_edits.extend([('delete', d[1], d[2]) for d in filtered_deletions])
    
    # 收集新增操作
    insertions = []
    for new_node in new_ast.linked_nodes :
        if not any(new_node == m[1] for m in M) and not (new_node.type == 'TopLevelFunction'):
            parent_new = find_matched_parent(new_node, M)
            if parent_new:
                parent_old = next(m[0] for m in M if m[1] == parent_new)
                insertions.append(('insert', new_node, parent_old, parent_new))
                affected_nodes.add(new_node)
                if not hasattr(new_node, 'edittype'):
                    new_node.edittype = 'insert'
    filtered_insertions = [i for i in insertions if not has_parent_in_list(i[1], insertions, is_deletion=False)]
    all_edits.extend([('insert', i[1], i[2], i[3]) for i in filtered_insertions])
    
    # 收集移动操作
    moves = []
    for old_node, new_node in M:
        old_parent = old_node.parent
        new_parent = new_node.parent
        
        # 检查父节点是否也匹配（即父节点未被移动）
        parent_match = False
        if old_parent is None and new_parent is None:
            parent_match = True
        elif old_parent is None or new_parent is None:
            parent_match = False
        else:
            try:
                parent_match = (new_parent == next(m[1] for m in M if m[0] == old_parent))
            except StopIteration:
                pass  # 没有找到匹配的父节点
        
        # 只有当父节点不匹配时才认为是移动操作
        if not parent_match:
            if not is_node_in_deletions(old_node, filtered_deletions) and \
            not is_node_in_insertions(new_node, filtered_insertions):
                moves.append(('move', old_node, old_parent, new_node, new_parent))
                affected_nodes.add(old_node)
                affected_nodes.add(new_node)

    all_edits.extend([('move', m[1], m[2], m[3], m[4]) for m in moves])
    
    # 收集更新操作
    updates = []
    for old_node, new_node in M:
        if not nodes_equal(old_node, new_node):
            updates.append(('update', old_node, new_node))
            affected_nodes.add(old_node)
            affected_nodes.add(new_node)
    all_edits.extend([('update', u[1], u[2]) for u in updates])

    # 2. 按优先级处理所有编辑操作，为节点分配target_id
    # 先按操作类型排序，优先级高的在前
    all_edits.sort(key=lambda x: priority_order[x[0]])
    
    # 遍历所有编辑操作，为涉及到的节点分配target_id
    for edit in all_edits:
        op_type = edit[0]
        nodes_involved = []
        
        # 根据操作类型确定涉及的节点
        if op_type == 'delete':
            nodes_involved = [edit[1]]  # 被删除的节点
        elif op_type == 'insert':
            nodes_involved = [edit[1]]  # 新增的节点
        elif op_type == 'move':
            nodes_involved = [edit[1], edit[3]]  # 旧节点和新节点
        elif op_type == 'update':
            nodes_involved = [edit[1], edit[2]]  # 旧节点和新节点
        
        # 为操作中尚未分配target_id的节点分配新的target_id
        target_id = None
        for node in nodes_involved:
            if node in node_target_map:
                # 如果节点已经有target_id，则使用已有的
                target_id = node_target_map[node]
                break
        
        if target_id is None:
            # 如果没有节点有target_id，则创建新的
            target_id = f"target_{node_counter}"
            node_counter += 1
        
        # 为所有涉及的节点设置target_id（如果尚未设置）
        for node in nodes_involved:
            if node not in node_target_map:
                node_target_map[node] = target_id
                node.target_id = target_id  # 为节点添加target_id属性
        
        # 将编辑操作添加到editscript中（带上target_id）
        if op_type == 'delete':
            editscript.append(('delete', edit[1], edit[2], target_id))
        elif op_type == 'insert':
            editscript.append(('insert', edit[1], edit[2], edit[3], target_id))
        elif op_type == 'move':
            editscript.append(('move', edit[1], edit[2], edit[3], edit[4], target_id))
        elif op_type == 'update':
            editscript.append(('update', edit[1], edit[2], target_id))
    # 获取关键变量        
    # 获取所有受影响节点中声明的变量名
    declared_vars_in_edits = set()
    for node in affected_nodes:
        if node and node.type == 'VariableDeclarationEntry':
            # 从"definition of xxx"中提取实际变量名
            if node.value.startswith('definition of '):
                var_name = node.value[len('definition of '):]
                declared_vars_in_edits.add(var_name)
    # 获取所有受影响节点中的变量访问节点
    variable_access_nodes = []
    #print("variable_access_nodes: ")
    for node in old_ast.linked_nodes + new_ast.linked_nodes:
        if node and node.type == 'VariableAccess':  
            variable_access_nodes.append(node)
            #print(node)   
    key_variable_nodes=[]
    for var_node in variable_access_nodes:
        var_name = var_node.value
        # 跳过在编辑范围内已声明的变量
        if var_name in declared_vars_in_edits:
            continue
        # 在原始AST中查找变量声明
        declaration_node = None
        for old_node in old_ast.linked_nodes:
            if (old_node.type == 'VariableDeclarationEntry' and 
                old_node.value.startswith('definition of ') and 
                old_node.value[len('definition of '):] == var_name):
                declaration_node = old_node
                break
        if not declaration_node:
            for new_node in new_ast.linked_nodes:
                if (new_node.type == 'VariableDeclarationEntry' and 
                    new_node.value.startswith('definition of ') and 
                    new_node.value[len('definition of '):] == var_name):
                    declaration_node = new_node
                    break
        
        if declaration_node:
            # 提取位置信息中的起始行号
            loc_part = declaration_node.location.split('@')[-1].split(':')[0]
            line_num = loc_part.split('_')[0] if '_' in loc_part else loc_part
            var_id = f"v{var_name}_{line_num}"
            declaration_node.out_var = var_id
            if var_node in affected_nodes:
                key_variable_nodes.append((declaration_node,True))
            else:
                key_variable_nodes.append((declaration_node,False))
            
            # 仅添加到当前变量访问节点
            if not hasattr(var_node, 'out_var'):
                var_node.out_var = var_id
    #去重
    key_variable_nodes = list({
        node.out_var: (node, bool_cond)
        for node, bool_cond in sorted(
            key_variable_nodes,
            key=lambda x: (x[0].out_var, -x[1])  
        )
    }.values())
    return editscript, key_variable_nodes

