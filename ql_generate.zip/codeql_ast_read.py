import re
from collections import defaultdict

class ASTNode:
    def __init__(self, location, type, value):
        self.location = location
        self.type = type
        self.value = value
        self.features = {}
        self.children = []
        self.parent = None

    def __repr__(self):
        return f"{self.type}('{self.value}') @{self.location}"


class ASTEdge:
    def __init__(self, source, target, type, order=0):
        self.source = source
        self.target = target
        self.type = type
        self.order = order


class ASTBuilder:
    def __init__(self, nodes_file, edges_file):
        self.nodes_file = nodes_file
        self.edges_file = edges_file
        self.nodes = []  # 所有节点
        self.loc_to_nodes = defaultdict(list)
        self.edges = []
        self.root = None
        self.linked_nodes = []  # 连接的节点

    @staticmethod
    def _extract_location(uri_or_loc):
        match = re.search(r'(\d+:\d+:\d+:\d+)', uri_or_loc)
        return match.group(1) if match else ''

    def load_nodes(self):
        node_features = defaultdict(dict)
        reading = False

        with open(self.nodes_file, encoding='utf-8') as f:
            for line in f:
                if 'Result set: #select' in line:
                    reading = True
                    continue
                if reading:
                    parts = [x.strip() for x in line.strip().split('|') if x.strip()]
                    if len(parts) != 4:
                        continue
                    node_label, key, value, loc = parts
                    loc_id = self._extract_location(loc)
                    if not loc_id:
                        continue

                    if key == "semmle.label":
                        type_match = re.search(r'\[(.*?)\]', node_label)
                        node_type = type_match.group(1) if type_match else "Unknown"
                        node_value = node_label.split(']')[-1].strip()
                        node = ASTNode(loc_id, node_type, node_value)
                        self.nodes.append(node)
                        self.loc_to_nodes[loc_id].append(node)
                    else:
                        node_features[loc_id][key] = value

        for loc_id, feats in node_features.items():
            for node in self.loc_to_nodes.get(loc_id, []):
                node.features = feats

    def load_edges(self):
        edge_records = defaultdict(dict)
        reading = False

        with open(self.edges_file, encoding='utf-8') as f:
            for line in f:
                if 'Result set: #select' in line:
                    reading = True
                    continue
                if reading:
                    parts = [x.strip() for x in line.strip().split('|') if x.strip()]
                    if len(parts) != 6:
                        continue
                    _, _, key, value, sloc, tloc = parts
                    src_loc = self._extract_location(sloc)
                    tgt_loc = self._extract_location(tloc)

                    if not tgt_loc or not src_loc:
                        continue

                    edge_records[(src_loc, tgt_loc)][key] = value

        for (src_loc, tgt_loc), props in edge_records.items():
            src_nodes = self.loc_to_nodes.get(src_loc, [])
            tgt_nodes = self.loc_to_nodes.get(tgt_loc, [])
            if not src_nodes or not tgt_nodes:
                continue

            src_node = src_nodes[0]
            tgt_node = tgt_nodes[0]

            edge = ASTEdge(
                src_node,
                tgt_node,
                props.get("semmle.label", "Unknown"),
                int(props.get("semmle.order", "0"))
            )
            self.edges.append(edge)
            src_node.children.append(tgt_node)
            tgt_node.parent = src_node

    def _update_linked_nodes(self):
        linked = set()
        for edge in self.edges:
            linked.add(edge.source)
            linked.add(edge.target)
        self.linked_nodes = sorted(linked, key=lambda n: n.location)

    def build(self):
        self.load_nodes()
        self.load_edges()
        self._update_linked_nodes()
        for node in self.nodes:
            if node.type == 'TopLevelFunction':
                self.root = node
                break
        if not self.root and self.nodes:
            self.root = self.nodes[0]
        return self.root

    def get_node(self, loc, type):
        for node in self.nodes:
            if node.location == loc and node.type == type:
                return node
        return None

    def print_ast(self, node=None, indent=0):
        if node is None:
            node = self.root
        print('  ' * indent + repr(node))
        for child in node.children:
            self.print_ast(child, indent + 1)

    def find_unlinked_nodes(self):
        linked = set(self.linked_nodes)
        all_nodes = set(self.nodes)
        unlinked = all_nodes - linked
        print(f"Unlinked nodes ({len(unlinked)}):")
        for node in sorted(unlinked, key=lambda n: n.location):
            print(f"  - {node}")

