from editscript import *
from codeql_ast_read import *
from codeql_ast_match import *
from ql_generate  import *

def generate_ql_query(ast_nodes_file, ast_edges_file, ast_nodes_patched_file, ast_edges_patched_file):
    # 初始化AST构建器
    ast1 = ASTBuilder(ast_nodes_file, ast_edges_file)
    ast2 = ASTBuilder(ast_nodes_patched_file, ast_edges_patched_file)
    
    # 构建完整AST
    root1 = ast1.build()
    root2 = ast2.build()
    
    # 匹配AST节点
    matcher = ASTMatcher(root1, root2)
    matched_pairs = matcher.match()
    
    # 生成编辑脚本和关键变量节点
    editscript, key_variable_nodes = generate_editscript(ast1, ast2, matched_pairs)
    #print(key_variable_nodes)
    # 收集所有节点并应用CFG优化
    all_nodes = [edit[1] for edit in editscript]
    new_nodes = cfg_refine(all_nodes, match_pairs=matched_pairs)
    
    # 生成QL查询内容
    ql_content = "import cpp\n\n"
    predicates = []
    predicate_params = {}  # 存储每个谓词的参数（带类型）
    predicate_param_names = {}  # 存储每个谓词的参数名（不带类型）
    predicate_types = {}   # 存储每个谓词的生成器类型
    
    # 生成编辑操作的谓词
    for i, edit in enumerate(editscript):
        op_type = edit[0]
        
        if op_type == 'delete':
            generator = ASTDelPredicateGenerator()
            predicate, param_str = generator.generate(edit[1], i)
            predicate_types[f"func_{i}"] = 'delete'
        elif op_type == 'insert':
            generator = ASTAddPredicateGenerator()
            predicate, param_str = generator.generate(edit[1], i)
            predicate_types[f"func_{i}"] = 'insert'
        elif op_type == 'move':
            generator = ASTMovePredicateGenerator()
            predicate, param_str = generator.generate(edit[1], i)
            predicate_types[f"func_{i}"] = 'move'
        elif op_type == 'update':
            generator = ASTUpdatePredicateGenerator()
            predicate, param_str = generator.generate(edit[1], edit[3], i)
            predicate_types[f"func_{i}"] = 'update'
        
        predicates.append(predicate)
        predicate_params[f"func_{i}"] = param_str
        # 提取参数名，去掉类型部分
        param_names = [p.split()[-1] for p in param_str.split(", ")]
        predicate_param_names[f"func_{i}"] = ", ".join(param_names)
    
    # 生成新节点的谓词
    for i, node in enumerate(new_nodes):
        generator = ASTDelPredicateGenerator()
        predicate, param_str = generator.generate(node, i + len(all_nodes))
        predicates.append(predicate)
        predicate_types[f"func_{i + len(all_nodes)}"] = 'delete'
        predicate_params[f"func_{i + len(all_nodes)}"] = param_str
        param_names = [p.split()[-1] for p in param_str.split(", ")]
        predicate_param_names[f"func_{i + len(all_nodes)}"] = ", ".join(param_names)
    
    # 添加所有谓词到QL内容
    ql_content += "\n\n".join(predicates) + "\n\n"
    
    # 添加查询部分
    ql_content += "from Function func"
    
    # 收集所有需要的变量声明（带类型）
    all_vars = set()
    for params in predicate_params.values():
        for param in params.split(", "):
            all_vars.add(param)
    
    # 添加变量声明（带类型）
    for var in sorted(all_vars):
        ql_content += f", {var}"
    
    ql_content += "\nwhere\n"
    
    # 添加谓词条件（使用不带类型的参数名）
    for i in range(len(predicate_param_names)):
        pred_name = f"func_{i}"
        # 根据生成器类型决定是否添加not
        if predicate_types[pred_name] == 'insert':
            ql_content += f"not {pred_name}({predicate_param_names[pred_name]})"
        else:
            ql_content += f"{pred_name}({predicate_param_names[pred_name]})"
        
        if i < len(predicate_param_names) - 1:
            ql_content += "\nand "
    
    #补充关键变量
    for var in all_vars:
        if var.startswith("Variable"):
            for i, (node, bool_cond) in enumerate(key_variable_nodes):
                if node.out_var == var.split()[-1]:
                    key_variable_nodes[i] = (node, True)
                
    # 生成关键变量条件
    key_var_cond = generate_key_variable_conditions(key_variable_nodes)
    
    # 添加关键变量条件
    ql_content += "\n" + key_var_cond + "\n"
    
    # 添加select语句
    ql_content += "select func, func.getFile().toString() + \":\" + func.getLocation().getStartLine().toString()"
    
    return ql_content

if __name__ == '__main__':
    ql_query = generate_ql_query('ASTNodes.txt', 'ASTEdges.txt', 
                           'ASTNodes_patched.txt', 'ASTEdges_patched.txt')
    print(ql_query)